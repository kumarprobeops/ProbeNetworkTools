import axios from 'axios';
import { getToken, clearToken } from './auth';

// Use VITE_API_URL for all environments (set in .env.frontend)

console.log("VITE_API_URL being used:", import.meta.env.VITE_API_URL);

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL, // Always use the env variable!
  timeout: 60000 // 60 seconds
});

// Request interceptor to add auth header
api.interceptors.request.use(
  (config) => {
    const token = getToken();
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      clearToken();
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Helper for error messages
const handleApiError = (error) => {
  console.error('API Error:', error);
  let errorMessage = 'An unexpected error occurred';
  if (error.response) {
    const data = error.response.data;
    if (error.response.status === 401) {
      errorMessage = 'Incorrect username or password. Please try again.';
    } else if (error.response.status === 500) {
      errorMessage = 'Server error. Please try again in a few moments.';
    } else if (error.response.status === 404) {
      errorMessage = 'The requested resource was not found.';
    } else if (error.response.status === 403) {
      errorMessage = 'You do not have permission to access this resource.';
    } else {
      errorMessage = data.detail || data.message || `Error: ${error.response.status}`;
    }
    console.log('Error response data:', data);
  } else if (error.request) {
    errorMessage = 'No response from server. Please check your connection.';
  }
  throw new Error(errorMessage);
};

// *** UPDATED LOGIN FUNCTION ***
export const loginUser = async (username, password) => {
  try {
    const response = await api.post('/auth/login', {
      username,
      password
    });
    if (response.data && response.data.access_token) {
      localStorage.setItem('probeops_token', response.data.access_token);
    }
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

// *** UPDATED REGISTER FUNCTION ***
export const registerUser = async (username, email, password) => {
  try {
    const response = await api.post('/auth/register', {
      username,
      email,
      password
    });
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

// --- Rest of your APIs ---

export const getUserProfile = async () => {
  try {
    console.log("Fetching user profile...");
    try {
      const response = await api.get('/api/users/me');
      console.log("User profile response:", response.data);
      return response.data;
    } catch (firstError) {
      console.log("First user profile attempt failed, trying alternative endpoint");
      const altResponse = await api.get('/user');
      console.log("Alternative user profile response:", altResponse.data);
      return altResponse.data;
    }
  } catch (error) {
    console.log("Error fetching user profile:", error);
    return handleApiError(error);
  }
};

export const updateUserProfile = async (profileData) => {
  try {
    const response = await api.put('/api/users/me', profileData);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const changePassword = async (currentPassword, newPassword) => {
  try {
    const response = await api.post('/api/users/me/change-password', {
      current_password: currentPassword,
      new_password: newPassword
    });
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const resendVerificationEmail = async () => {
  try {
    const response = await api.post('/api/users/me/resend-verification');
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const logoutAllDevices = async () => {
  try {
    const response = await api.post('/api/users/me/logout-all');
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

// Diagnostic APIs
export const runDiagnostic = async (tool, params = {}, data = null) => {
  try {
    console.log(`Running diagnostic ${tool} with params:`, params);

    // Always ensure the user is authenticated
    const token = getToken();
    if (!token) {
      console.error('No authentication token available');
      return {
        status: 'failure',
        result: 'Error: Not authenticated. Please log in again.',
        created_at: new Date().toISOString(),
        tool: tool,
        target: params.target || ''
      };
    }

    // Map tool if needed (e.g., nmap -> port_check)
    let jobType = tool;
    if (tool === "nmap") jobType = "port_check";

    // Construct the payload
    const payload = { type: jobType, target: params.target };

    // Add extra params if needed (e.g., port)
    if (jobType === "port_check" && params.port) {
      payload.port = params.port;
    }

    // Add any other tool-specific params here if needed

    // POST to /probe endpoint
    const response = await api.post("/probe", payload);

    console.log(`Diagnostic ${tool} response:`, response.data);

    return response.data;
  } catch (error) {
    console.log("Error response data:", error.response?.data);
    console.log("Full error:", error);

    // Create a properly formatted error response
    return {
      tool: tool,
      target: params.target || '',
      created_at: new Date().toISOString(),
      execution_time: 0,
      status: 'failure',
      result: `Error: ${error.message || 'An unknown error occurred'}\n\n${error.response?.data ? JSON.stringify(error.response.data) : ''}`
    };
  }
};

export const getDiagnosticHistory = async (params = {}) => {
  try {
    console.log("Fetching diagnostic history with params:", params);
    const response = await api.get('/history', { params });
    console.log("History response:", response);
    return response.data;
  } catch (error) {
    console.error("Error fetching diagnostic history:", error);
    if (error.response && error.response.status === 404) {
      console.log("History endpoint not found, returning empty array");
      return [];
    }
    return handleApiError(error);
  }
};

export const getDashboardMetrics = async () => {
  try {
    console.log("Attempting to fetch dashboard metrics from /metrics/dashboard");
    console.log("Current auth token:", api.defaults.headers.common['Authorization'] ? 'Present' : 'Not present');

    const response = await api.get('/metrics/dashboard');
    console.log("SUCCESS! Dashboard metrics response:", response.data);
    return response.data;
  } catch (error) {
    console.error("Error fetching dashboard data:", error);
    console.error("Error response:", error.response);
    try {
      console.log("Trying alternative dashboard metrics path '/api/metrics/dashboard'");
      const response = await api.get('/api/metrics/dashboard');
      console.log("Alternative metrics response:", response.data);
      return response.data;
    } catch (alternativeError) {
      console.error("Alternative path also failed:", alternativeError);
      return {
        diagnostic_count: 0,
        api_key_count: 0,
        scheduled_probe_count: 0,
        success_rate: 0,
        avg_response_time: 0
      };
    }
  }
};

// API Key APIs
export const getApiKeys = async () => {
  try {
    const response = await api.get('/keys');
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const createApiKey = async (data) => {
  try {
    console.log("Creating API key with form data:", data);
    const url = '/keys/';  // No query params needed
    const response = await fetch(`${import.meta.env.VITE_API_URL}${url}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${getToken()}`
      },
      body: JSON.stringify({ name: data.name, expires_days: data.expires_days })
    });

    if (!response.ok) {
      // Try to read the JSON error from backend
      let errorDetail = '';
      try {
        const errorData = await response.json();
        errorDetail = errorData.detail || errorData.message || '';
      } catch (e) {}
      throw new Error(errorDetail || `Server returned ${response.status}: ${response.statusText}`);
    }

    const responseData = await response.json();
    console.log("API key created successfully:", responseData);
    return responseData;
  } catch (error) {
    console.error("Error creating API key:", error);
    const errorDetails = {
      message: error.message,
      stack: error.stack
    };
    console.error("Error details:", errorDetails);
    throw error;
  }
};

export const deleteApiKey = async (keyId) => {
  try {
    const response = await api.delete(`/keys/${keyId}`);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const deactivateApiKey = async (keyId) => {
  try {
    console.log(`Deactivating API token with ID ${keyId}`);
    const token = getToken();

    if (!token) {
      throw new Error('No authentication token available');
    }

    const response = await api.put(`/keys/${keyId}/deactivate`, {}, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });

    console.log("API token deactivated successfully:", response.data);
    return response.data;
  } catch (error) {
    console.error("Error deactivating API token:", error);
    throw error;
  }
};

export const activateApiKey = async (keyId) => {
  try {
    console.log(`Activating API token with ID ${keyId}`);
    const token = getToken();

    if (!token) {
      throw new Error('No authentication token available');
    }

    const response = await api.put(`/keys/${keyId}/activate`, {}, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });

    console.log("API token activated successfully:", response.data);
    return response.data;
  } catch (error) {
    console.error("Error activating API token:", error);
    throw error;
  }
};

// Scheduled Probes APIs
export const getScheduledProbes = async (params = {}) => {
  try {
    const response = await api.get('/probes', { params });
    return response.data;
  } catch (error) {
    if (error.response && error.response.status === 404) {
      return [];
    }
    return handleApiError(error);
  }
};

export const getScheduledProbeById = async (probeId) => {
  try {
    const response = await api.get(`/probes/${probeId}`);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const createScheduledProbe = async (probeData) => {
  try {
    console.log("Attempting to create scheduled probe with data:", probeData);
    try {
      const response = await api.post('/probes', probeData);
      console.log("Probe created successfully:", response.data);
      return response.data;
    } catch (error) {
      console.error("First endpoint failed:", error.message);
      if (error.response && error.response.status === 405) {
        console.log("Trying alternative probe creation endpoint...");
        const altResponse = await api.post('/scheduled-probes', probeData);
        console.log("Probe created successfully with alternative endpoint:", altResponse.data);
        return altResponse.data;
      } else {
        console.log("Trying with /api prefix...");
        const apiResponse = await api.post('/api/probes', probeData);
        console.log("Probe created successfully with /api prefix:", apiResponse.data);
        return apiResponse.data;
      }
    }
  } catch (error) {
    console.error("All probe creation endpoints failed:", error);
    return handleApiError(error);
  }
};

export const updateScheduledProbe = async (probeId, probeData) => {
  try {
    const response = await api.put(`/probes/${probeId}`, probeData);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const deleteScheduledProbe = async (probeId) => {
  try {
    const response = await api.delete(`/probes/${probeId}`);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const pauseScheduledProbe = async (probeId) => {
  try {
    const response = await api.put(`/probes/${probeId}/pause`);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const resumeScheduledProbe = async (probeId) => {
  try {
    const response = await api.put(`/probes/${probeId}/resume`);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const getProbeResults = async (probeId, params = {}) => {
  try {
    const response = await api.get(`/probes/${probeId}/results`, { params });
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const bulkPauseProbes = async (probeIds) => {
  try {
    const response = await api.post('/probes/bulk-pause', probeIds);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const bulkResumeProbes = async (probeIds) => {
  try {
    const response = await api.post('/probes/bulk-resume', probeIds);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const bulkDeleteProbes = async (probeIds) => {
  try {
    const response = await api.post('/probes/bulk-delete', probeIds);
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

// Reports APIs
export const generateReport = async (params = {}) => {
  try {
    const response = await api.post('/reports/generate', params);
    return response.data;
  } catch (error) {
    if (error.response && error.response.status === 404) {
      return { message: "Report generation endpoint not available" };
    }
    return handleApiError(error);
  }
};

export const exportReport = async (format = 'pdf', reportId) => {
  try {
    const response = await api.get(`/reports/${reportId}/export`, {
      params: { format },
      responseType: 'blob'
    });
    return response.data;
  } catch (error) {
    return handleApiError(error);
  }
};

export const getReportHistory = async (params = {}) => {
  try {
    const response = await api.get('/reports', { params });
    return response.data;
  } catch (error) {
    if (error.response && error.response.status === 404) {
      return [];
    }
    return handleApiError(error);
  }
};

export default api;